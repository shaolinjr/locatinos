import {Component, OnInit} from "@angular/core"

@Component({
  selector: 'locatinos-app',
  templateUrl: 'app.component.html'
})
export class AppComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
