export interface Carousel{
  id:string,
  titulo:string,
  imageUrl:string
}